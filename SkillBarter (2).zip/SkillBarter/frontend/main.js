// dashboard.js
// Sample data - Replace with actual data from your backend
let mySkills = [
    { id: 1, name: "Web Development", category: "Programming" },
    { id: 2, name: "Graphic Design", category: "Design" }
];

let otherOffers = [
    { id: 1, user: "JohnDoe", skill: "Photography", offer: "Portrait Sessions", city: "New York" },
    { id: 2, user: "JaneSmith", skill: "Cooking", offer: "Italian Cuisine Lessons", city: "London" }
];

function showMySkills() {
    document.getElementById('mySkills').classList.remove('hidden');
    document.getElementById('otherOffers').classList.add('hidden');
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    populateMySkills();
}

function showOtherOffers() {
    document.getElementById('otherOffers').classList.remove('hidden');
    document.getElementById('mySkills').classList.add('hidden');
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    populateOtherOffers();
}

function populateMySkills() {
    const skillsList = document.getElementById('skillsList');
    skillsList.innerHTML = mySkills.map(skill => `
        <div class="skill-card">
            <div>
                <h3>${skill.name}</h3>
                <p>${skill.category}</p>
            </div>
            <div class="skill-actions">
                <button onclick="removeSkill(${skill.id})">Remove</button>
            </div>
        </div>
    `).join('');
}

function populateOtherOffers() {
    const offersList = document.getElementById('offersList');
    offersList.innerHTML = otherOffers.map(offer => `
        <div class="offer-card">
            <div>
                <h3>${offer.user}</h3>
                <p>${offer.skill} - ${offer.offer}</p>
                <span class="city">📍 ${offer.city}</span>
            </div>
        </div>
    `).join('');
}

function addSkill() {
    const newSkillInput = document.getElementById('newSkill');
    if (newSkillInput.value.trim()) {
        mySkills.push({
            id: Date.now(),
            name: newSkillInput.value.trim(),
            category: "General"
        });
        newSkillInput.value = '';
        populateMySkills();
    }
}

function removeSkill(skillId) {
    mySkills = mySkills.filter(skill => skill.id !== skillId);
    populateMySkills();
}

// Initial load
populateMySkills();
populateOtherOffers();