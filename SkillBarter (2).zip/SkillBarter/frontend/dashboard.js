let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    // Get user from localStorage (you should implement proper session management)
    currentUser = localStorage.getItem('currentUser');
    if (!currentUser) window.location.href = '/';
    
    // loadSkills();
    
    document.getElementById('skillForm').addEventListener('submit', addSkill);
});

function toggleDropdown() {
    document.getElementById('dropdownMenu').classList.toggle('show');
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '/frontend/auth.html';
}

// async function loadSkills() {
//     try {
//         const response = await fetch('http://localhost:3000/api/skills');
//         const skills = await response.json();
        
//         displayMySkills(skills.filter(skill => skill.user_id === currentUser)); //.userId
//         displayOtherSkills(skills.filter(skill => skill.user_id !== currentUser));
//     } catch (err) {
//         console.error('Error loading skills:', err);
//     }
// }

// function displayMySkills(skills) {
//     const container = document.getElementById('mySkills');
//     container.innerHTML = skills.map(skill => `
//         <div class="skill-card">
//             <h3>${skill.skill_name}</h3>
//             <p>${skill.description}</p>
//             <p>📍 ${skill.city}</p>
//         </div>
//     `).join('');
// }

// function displayOtherSkills(skills) {
//     const container = document.getElementById('otherSkills');
//     container.innerHTML = skills.map(skill => `
//         <div class="skill-card">
//             <h3>${skill.skill_name}</h3>
//             <p>${skill.description}</p>
//             <p>📍 ${skill.city}</p>
//             <button  type="button" class="accept-btn" onclick="acceptSkill(${skill.id})">Accept</button>
//         </div>
//     `).join('');
// }

async function addSkill(e) {
     e.preventDefault();
    
    // const skill = {
    //     user_id: currentUser,
    //     skill_name: document.getElementById('skillName').value,
    //     description: document.getElementById('skillDesc').value,
    //     city: document.getElementById('skillCity').value
    // };
    const user_id=`${currentUser}`;
    const skill_name= document.getElementById('skillName').value;
    const description= document.getElementById('skillDesc').value;
    const city =document.getElementById('skillCity').value;



    try {
        const response = await fetch('http://localhost:3000/api/skills', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({user_id, skill_name, description, city})
        });

        if (response.ok) {
            document.getElementById('skillForm').reset();
            // loadSkills();
        }
    } catch (err) {
        console.error('Error adding skill:', err);
    }
}

// async function acceptSkill(skillId) {
//     // Implement accept functionality
//     alert(`Skill ${skillId} accepted!`);
//     // Add your implementation here
// }