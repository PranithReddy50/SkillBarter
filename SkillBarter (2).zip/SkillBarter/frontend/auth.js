
function showLogin() {
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('registerForm').classList.add('hidden');
    document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

function showRegister() {
    document.getElementById('registerForm').classList.remove('hidden');
    document.getElementById('loginForm').classList.add('hidden');
    document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// Form validation and submission handling
// document.querySelectorAll('.auth-form').forEach(form => {
//     form.addEventListener('submit', (e) => {
//         e.preventDefault();
//         // Add your form submission logic here


//         alert('Form submitted successfully!');
//     });
// });

async function register() {
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, username, password })
      });
  
      const data = await response.json(); // Parse response even for errors
  
      if (response.ok) {
        alert('Registration successful! User ID: ' + data.userId);
      } else {
        alert('Error: ' + data.error); // Show backend error message
      }
    } catch (err) {
      alert('Failed to connect to the server!');
    }
  }



  async function login() {
    const username = document.getElementById('loginusername').value;
    const password = document.getElementById('loginpassword').value;
  
    try {
      const response = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
  
      const contentType = response.headers.get('content-type');
      
      if (!contentType?.includes('application/json')) {
        throw new Error(`Unexpected content type: ${contentType}`);
      }
  
      const data = await response.json();
  
      if (response.ok) {
        // alert('Login successful! Welcome ' + data.username);
        localStorage.setItem('currentUser', `${username}`);

        window.location.href = '/frontend/dashboard.html';
      } else {
        alert('Error: ' + (data.error || 'Unknown error'));
      }
    } catch (err) {
      alert(err.message || 'Failed to connect to server');
    }
  }