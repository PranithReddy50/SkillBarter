const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.get('/favicon.ico', (req, res) => res.status(204).end());

app.use((req, res, next) => {
  res.setHeader('Content-Type', 'application/json');
  next();
});  


app.get('/api/test', (req, res) => {
  res.send('Server is working!');
  
});

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '@Ppr12345',
  database: 'skillswap',
  waitForConnections: true,
  connectionLimit: 10
});

// Verify database connection
pool.getConnection((err, connection) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message);
    if (err.code === 'ER_BAD_DB_ERROR') {
      console.error('Database "skillswap" does not exist!');
    }
    return;
  }
  console.log('✅ Connected to MySQL');
  connection.release();
});





// Updated login endpoint
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  if (!username?.trim() || !password?.trim()) {
    return res.status(400).json({ error: 'Username and password required!' });
  }

  pool.query(
    'SELECT * FROM user WHERE username = ? AND password = ?',
    [username.trim(), password.trim()],
    (err, results) => {
      if (err) {
        console.error('MySQL Error:', err);
        return res.status(500).json({ error: 'Database error' }); // JSON response
      }

      if (results.length === 0) {
        return res.status(401).json({ error: 'Invalid credentials' }); // JSON response
      }

      res.json({
        userId: results[0].id,
        username: results[0].username,
        email: results[0].email
      });
    }
  );
});

// Existing registration endpoint
app.post('/api/register', (req, res) => {
    const { email, username, password } = req.body;

    if (!email || !username || !password) {
        return res.status(400).json({ error: 'All fields are required!' });
    }

    pool.query(
        'INSERT INTO user (email, username, password) VALUES (?, ?, ?)',
        [email, username, password],
        (err, result) => {
            if (err) {
                console.error('MySQL Error:', err.message);
                if (err.code === 'ER_DUP_ENTRY') {
                    return res.status(409).json({ error: 'Email already exists!' });
                }
                return res.status(500).json({ error: 'Registration failed!' });
            }
            res.json({ userId: result.insertId });
        }
    );
});



// Skills endpoints
app.get('/api/skills', (req, res) => {
  pool.query('SELECT * FROM skills', (err, results) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json(results);
  });
});

app.post('/api/skills', (req, res) => {
  const { user_id, skill_name, description, city } = req.body;

  if (!user_id || !skill_name || !city ||!description) {
    return res.status(400).json({ error: 'All fields are required!' });
    // alert("error");
}
  
  pool.query(
      'INSERT INTO skills (user_id, skill_name, description, city) VALUES (?, ?, ?, ?)',
      [user_id, skill_name, description, city],
      (err, result) => {
          if (err) return res.status(500).json({ error: 'Failed to add skill' });
          res.json({ id: result.insertId });
      }
  );
});

app.post('/api/skills/accept', (req, res) => {
  // Implement your accept logic here
  res.json({ message: 'Skill accepted' });
});

// 404 Handler - MUST be after all other routes
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Error handler - MUST be last middleware
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(3000, () => {
    console.log('🚀 Server running on http://localhost:3000');
});